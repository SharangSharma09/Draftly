// Content script for Draftly Chrome Extension
console.log('Draftly extension content script loaded');
