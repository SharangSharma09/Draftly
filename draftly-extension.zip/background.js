
// Background script for Draftly Chrome Extension
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

